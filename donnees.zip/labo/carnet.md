# Carnet du labo

Toutes les modifications essayées sur les robots du labo, gardées ou non. Les robots de la course
du présent ne changent qu'avec l'accord du propriétaire.

**Règles**
- On corrige des défauts de comportement, jamais « éviter ce qui a perdu » : aucune liste noire de placements ni de dates.
- Une seule correction à la fois. Gardée seulement si elle améliore l'entraînement (2016-2019) ET la validation (2020-2022).
- L'examen (2023-2026) n'est joué qu'une fois, à la toute fin.
- La version actuelle et la candidate lisent la même copie figée des archives : mêmes informations.
- Entraînement limité aux jours dont les actualités Google sont téléchargées ; validation sans actualités tant qu'elles ne sont pas arrivées.

---

## Tour 1 · 25/09/2026 vers 3h

**Référence (robots identiques au présent).** Entraînement du 26/09/2016 au 25/04/2019 (indice mondial +30,4 %), validation 2020-2022 (indice +17,1 %).

| Robot | Entraînement | Validation | Frais (entr. / valid.) | Ordres (entr. / valid.) |
|---|---|---|---|---|
| Prudent | +13,6 % | +5,6 % | 1 557 € / 1 985 € | 300 / 351 |
| Opportuniste | +20,0 % | +16,1 % | 696 € / 946 € | 78 / 97 |
| Audacieux | +18,7 % (chute max −44 %) | −27,3 % (chute max −60 %) | 22 405 € / 25 220 € | 412 / 467 |
| Kamikaze | −19,1 % | −53,6 % (chute max −80 %) | 23 510 € / 36 646 € | 657 / 1 175 |

Aucun robot ne bat l'indice. Défaut le plus coûteux : **Kamikaze s'agite**. 98 % de ses ordres sont des changements de cheval, il garde un placement 2 à 4 jours en moyenne, et il en change dès qu'il sort du top 2 de l'élan, un classement qui bouge chaque jour.

### Correction n°1 · Kamikaze garde un cheval tant qu'il reste dans le top 5 ✅ GARDÉE
- **Défaut** : revente dès qu'un placement sort du top 2, d'où des centaines d'allers-retours à ~0,3 % chacun.
- **Correction** : un placement déjà détenu est gardé tant qu'il reste dans le top 5 de l'élan (`garder_rang: 5`). À l'achat, il choisit toujours les 2 plus rapides. Règle générale : aucune liste de placements ni de dates.
- **Résultat** (même copie des archives pour les deux versions ; entraînement prolongé jusqu'au 19/09/2019 grâce aux nouvelles archives) :

| Kamikaze | Avant | Après |
|---|---|---|
| Entraînement | −35,1 % (chute max −50 %, 777 ordres) | **−8,8 %** (chute max −41 %, 557 ordres) |
| Validation | −53,6 % (chute max −80 %, 1 175 ordres) | **−21,4 %** (chute max −65 %, 813 ordres) |

- Mieux sur les deux périodes : **gardée dans le labo**. Kamikaze reste toutefois très loin de l'indice.
- Pas encore appliquée à la course du présent (en attente de ton accord).

## Tour 2 · 25/09/2026 vers 4h15

Les actualités Google couvrent maintenant toute l'année 2019 : l'entraînement va enfin jusqu'au 31/12/2019, comme prévu (indice mondial +43,1 %).

### Correction n°2 · Audacieux garde son marché d'accompagnement tant qu'il reste dans le top 5 ✅ GARDÉE
- **Défaut** : en posture « neutre », Audacieux met 50 % sur le marché qui a le plus d'élan. Il en changeait dès qu'un autre passait devant : 110 changements sur la validation.
- **Correction** : le marché d'accompagnement déjà choisi est gardé tant qu'il reste dans le top 5 de l'élan (`garder_rang: 5`). Même règle générale que la correction n°1, aucune liste de placements ni de dates.
- **Résultat** (même copie des archives pour les deux versions) :

| Audacieux | Avant | Après |
|---|---|---|
| Entraînement | +26,5 % (488 ordres, 25 992 € de frais) | **+29,5 %** (389 ordres, 21 019 €) |
| Validation | −28,2 % (481 ordres) | **−17,7 %** (422 ordres) |

- Mieux sur les deux périodes : **gardée dans le labo**. Audacieux reste derrière l'indice et subit toujours des chutes énormes (−44 % / −60 %). C'est son prochain défaut à étudier : le levier ×2 sans protection.
- Pas encore appliquée à la course du présent (en attente de ton accord).

## Tour 3 · 25/09/2026 vers 5h05

### Correction n°3 · Audacieux : pas d'attaque à 100 % Nasdaq ×2 si le Nasdaq est sous sa moyenne 200 jours ❌ REJETÉE
- **Défaut visé** : chutes énormes (jusqu'à −59 % sur la validation). Il passait en attaque au levier ×2 même quand la tendance de fond du Nasdaq était cassée (seule la moyenne 50 jours était vérifiée).
- **Correction essayée** : exiger en plus un Nasdaq au-dessus de sa moyenne 200 jours pour attaquer (`attaque_tendance_longue`).
- **Résultat** :

| Audacieux | Avant | Après |
|---|---|---|
| Entraînement | +29,5 % (chute max −43,6 %) | +28,2 % (chute max −42,3 %) |
| Validation | −15,7 % (chute max −58,6 %) | −9,4 % (chute max −55,5 %) |

- Mieux sur la validation, **moins bien sur l'entraînement** : la règle exige les deux, donc **rejetée**. Le code reste dans le labo mais désactivé.
- Remarque : la validation « avant » passe de −17,7 % (tour 2) à −15,7 %, car les actualités Google de 2020 sont arrivées entre-temps. Cela confirme que les résultats bougeront encore à mesure que les archives se complètent.

**Arrêt de la boucle à 5h47** (un nouveau tour aurait dépassé 6h).

## Tour 4 · 25/09/2026, 11h55 → 13h15 (une correction par robot, jugée robot par robot)

Entraînement du 26/09/2016 au 31/12/2019 (indice +43,1 %), validation 2020-2022 (indice +17,1 %). « Avant » = labo actuel (corrections n°1 et n°2 incluses).

| Robot | Correction essayée | Entraînement avant → après | Validation avant → après | Décision |
|---|---|---|---|---|
| Prudent | n°4 : part d'actions selon la **moyenne sur 5 jours** de la note de climat (au lieu de la note du moment) | +21,4 % → **+23,3 %** (416 → 280 ordres) | +10,1 % → **+11,0 %** | ✅ GARDÉE |
| Opportuniste | n°5 : hors tempête, **une seule mise** (8 %) gardée en liquide pour les occasions, le reste dans le cœur (au lieu de 25 à 50 % qui dormaient) | +28,0 % → **+30,5 %** (chute max −9,4 % → −13,7 %) | +15,6 % → **+17,6 %** (chute max −22,5 % → −23,2 %) | ✅ GARDÉE |
| Audacieux | n°6 : une posture (attaque/baisse) n'est quittée que si la note s'éloigne du seuil de **10 points** (anti-ping-pong) | +26,8 % → **+31,4 %** (401 → 314 ordres) | −16,4 % → **+7,4 %** (chute max −60 % → −51 %) | ✅ GARDÉE |
| Kamikaze | n°7 : n'acheter que des placements **au-dessus de leur moyenne 50 jours** | −10,4 % → −20,8 % | −21,4 % → +55,2 % | ❌ REJETÉE (pire à l'entraînement) |

- Opportuniste gagne plus mais chute un peu plus fort, logique puisqu'il est plus investi. La règle ne juge que la performance : gardée, en le signalant.
- Kamikaze n°7 : validation spectaculaire, mais l'entraînement se dégrade. Une règle qui ne marche que sur une période est probablement due à la chance de cette période : rejetée, comme prévu. Code désactivé.
- Remarque : les chiffres « avant » de Prudent et Opportuniste sont plus élevés qu'au tour 1, car l'entraînement va maintenant jusqu'à fin 2019 et les actualités 2019-2022 sont arrivées.

## Tour 5 · 25/09/2026, 13h20 → 14h55

| Robot | Correction essayée | Entraînement avant → après | Validation avant → après | Décision |
|---|---|---|---|---|
| Prudent | n°8 : obligations seulement si elles sont au-dessus de leur moyenne 200 jours, sinon placement sans risque | +23,1 % → +20,9 % | +11,0 % → +13,0 % | ❌ REJETÉE (pire à l'entraînement) |
| Opportuniste | n°9 : revendre une occasion dès que le rebond est fait (RSI > 50) | +30,8 % → +29,8 % | +17,64 % → +17,65 % | ❌ REJETÉE (pas mieux) |
| Audacieux | n°10 : pas d'attaque au levier si le VIX (peur) dépasse 25 | +31,8 % → +31,8 % (aucun effet) | +7,4 % → +3,1 % | ❌ REJETÉE |
| Kamikaze | n°11 : garder un placement au moins 3 jours (au lieu de 20 h) | −10,4 % → −14,0 % | −21,4 % → −39,7 % | ❌ REJETÉE |

Quatre rejets : c'est le filtre qui fonctionne, on ne garde pas une règle qui ne marche que sur une période. Codes désactivés.

## Tour 6 · 25/09/2026, 14h55 → 16h00

| Robot | Correction essayée | Entraînement avant → après | Validation avant → après | Décision |
|---|---|---|---|---|
| Prudent | n°12 : au moins 60 % d'actions quand l'indice mondial est au-dessus de ses moyennes 50 et 200 jours | +22,9 % → +21,9 % | +11,0 % → +8,6 % | ❌ REJETÉE |
| Opportuniste | n°13 : pas de « soldes » quand le marché mondial est sous sa moyenne 200 jours | +30,7 % → **+31,5 %** | +17,6 % → **+18,0 %** | ✅ GARDÉE (gain modeste) |
| Audacieux | n°14 : en posture neutre, Nasdaq sans levier (×1) quand il est sous sa moyenne 50 jours | +31,8 % → +11,2 % | +7,4 % → +3,9 % | ❌ REJETÉE |
| Kamikaze | n°15 : stop-loss proportionnel au levier (7 % du marché sous-jacent, soit −21 % sur un ×3) | −10,4 % → −12,8 % | −21,4 % → −42,6 % | ❌ REJETÉE |

- Remarque : les chiffres « avant » de Prudent bougent légèrement d'un tour à l'autre (+23,1 % → +22,9 %), car les archives BBC/CNBC de 2017 continuent d'arriver. Chaque comparaison avant/après reste faite sur la même copie figée.

## Tour 7 · 25/09/2026, 16h00 → 17h03

| Robot | Correction essayée | Entraînement avant → après | Validation avant → après | Décision |
|---|---|---|---|---|
| Prudent | n°16 : or seulement s'il est au-dessus de sa moyenne 200 jours | +22,7 % → +19,7 % | +11,0 % → +8,4 % | ❌ REJETÉE |
| Opportuniste | n°17 : pas de « solde » sur un placement à plus de 20 % sous son plus haut d'un an | +31,4 % → +31,4 % | +18,0 % → +18,0 % | ❌ REJETÉE (aucun effet : ne s'est jamais déclenchée) |
| Audacieux | n°18 : en posture « baisse », à l'abri dans le sans-risque au lieu du pari à la baisse ×2 | +32,8 % → **+48,9 %** | +7,4 % → +6,5 % | ❌ REJETÉE de justesse (un peu moins bien en validation) |
| Kamikaze | n°19 : répartition 50 / 50 entre ses deux chevaux (au lieu de 70 / 30) | −10,4 % → −5,4 % | −21,4 % → −25,7 % | ❌ REJETÉE |

- Audacieux n°18 est tentante (+16 points à l'entraînement), mais elle fait un peu moins bien en validation : la règle est la règle.

## Tour 8 · 25/09/2026, 17h04 → 18h08

| Robot | Correction essayée | Entraînement avant → après | Validation avant → après | Décision |
|---|---|---|---|---|
| Prudent | n°23 : réajuster seulement si un placement s'écarte de plus de 10 points (au lieu de 5) | +22,7 % → +21,4 % | +11,0 % → +11,2 % | ❌ REJETÉE (pire à l'entraînement) |
| Opportuniste | n°20 : revendre une occasion montée à +4 % si elle revient à zéro | +31,6 % → +31,6 % | +18,0 % → +17,1 % | ❌ REJETÉE |
| Audacieux | n°21 : 30 % de levier en posture neutre (au lieu de 50 %) | +30,0 % → +17,8 % | +7,4 % → −3,5 % | ❌ REJETÉE |
| Kamikaze | n°22 : paris à la baisse (ETF inverses) seulement quand le climat est à la tempête (note ≤ −30) | −11,7 % → **−7,9 %** | −21,4 % → **+21,5 %** | ✅ GARDÉE |

- Kamikaze n°22 : il achetait des paris à la baisse dès qu'ils « montaient vite » quelques jours, même en plein marché haussier. Il les réserve désormais aux vraies tempêtes. Premier résultat positif de Kamikaze en validation, au-dessus de l'indice (+17,1 %).

## Tour 9 · 25/09/2026, 18h08 → 19h13 (réglages existants, une seule valeur essayée)

| Robot | Correction essayée | Entraînement avant → après | Validation avant → après | Décision |
|---|---|---|---|---|
| Prudent | n°24 : jusqu'à 85 % d'actions par beau temps (au lieu de 75 %) | +22,5 % → **+24,2 %** | +11,0 % → **+11,9 %** | ✅ GARDÉE |
| Opportuniste | n°25 : une occasion a 30 jours pour rebondir (au lieu de 15) | +31,5 % → **+34,8 %** | +18,0 % → **+19,7 %** | ✅ GARDÉE |
| Audacieux | n°26 : posture « baisse » seulement sous −40 (au lieu de −25) | +32,4 % → +35,0 % | +7,4 % → −5,4 % | ❌ REJETÉE |
| Kamikaze | n°27 : changer de cheval seulement si l'autre a 6 points d'élan d'avance (au lieu de 3) | +1,4 % → −24,1 % | +21,5 % → +31,1 % | ❌ REJETÉE |

- Kamikaze « avant » passe de −7,9 % (tour 8) à +1,4 % à l'entraînement : les archives BBC/CNBC de 2017 continuent d'arriver et changent le ton des actualités, qui compte dans sa règle n°22 (climat de tempête). Kamikaze reste le robot le plus sensible aux données.

## Tour 10 · 25/09/2026, 19h13 → 20h19 (dernier tour de la journée)

| Robot | Correction essayée | Entraînement avant → après | Validation avant → après | Décision |
|---|---|---|---|---|
| Prudent | n°28 : au moins 45 % d'actions même par tempête (au lieu de 35 %) | +24,7 % → **+27,6 %** | +11,9 % → **+14,0 %** | ✅ GARDÉE |
| Opportuniste | n°29 : 12 % du portefeuille par occasion (au lieu de 8 %) | +35,4 % → +37,5 % | +19,7 % → +19,2 % | ❌ REJETÉE |
| Audacieux | n°30 : attaque dès une note de climat de 5 (au lieu de 15) | +36,0 % → +44,4 % | +7,4 % → −1,0 % | ❌ REJETÉE |
| Kamikaze | n°31 : stop-loss à −10 % (au lieu de −7 %) | +22,9 % → +22,1 % | +21,5 % → +53,8 % | ❌ REJETÉE de justesse |

**Attention, Kamikaze est instable.** Sa version « avant » est passée de −7,9 % (tour 8) à +1,4 % (tour 9) puis +22,9 % (tour 10) à l'entraînement, sans aucune modification de son code. Seules les archives BBC/CNBC arrivées entre-temps ont changé, et avec elles le ton des actualités qu'il lit. Ses résultats dépendent énormément des données : il faudra le re-tester quand toutes les archives seront là.

---

## Bilan du 25/09/2026 (arrêt de la boucle à 20h19)

**Corrections gardées dans le labo (9) :**
- Prudent : n°4 (climat lissé sur 5 jours), n°24 (jusqu'à 85 % d'actions), n°28 (au moins 45 % d'actions).
- Opportuniste : n°5 (une seule mise en réserve), n°13 (pas de soldes en marché baissier), n°25 (30 jours pour rebondir).
- Audacieux : n°2 (garde son marché d'accompagnement), n°6 (marge anti-ping-pong de 10 points).
- Kamikaze : n°1 (garde un placement tant qu'il est dans le top 5), n°22 (paris à la baisse seulement par tempête).

**Rejetées : 22 corrections** (voir chaque tour).

**Robots du labo, derniers chiffres** (indice mondial : +43,1 % à l'entraînement 2016-2019, +17,1 % en validation 2020-2022) :

| Robot | Entraînement | Validation |
|---|---|---|
| Prudent | +27,6 % | +14,0 % |
| Opportuniste | +35,4 % | **+19,7 %** (bat l'indice) |
| Audacieux | +36,0 % | +7,4 % |
| Kamikaze | +22,9 % (instable) | **+21,5 %** (bat l'indice) |

Examen 2023-2026 : pas encore joué. Robots de la course du présent : inchangés.

---

# Méthode B (à partir du 26/09/2026) — voir data/labo/methodes.md

**Nouvelle règle** : une correction n'est gardée que si elle fait mieux à l'entraînement (2016-2019) ET sur
CHACUNE des années 2020, 2021 et 2022 simulées séparément. Au plus 3 essais par robot. Priorité aux défauts
de comportement. La version de départ est la version finale de la méthode A (figée dans data/labo/versions/methode_A/).

## Tour 11 · référence de la méthode B
Robots du labo tels qu'à la fin de la méthode A, rejoués année par année (26/09, 2 h de calcul).

| Robot | Entraînement 2016-2019 | 2020 | 2021 | 2022 |
|---|---|---|---|---|
| Indice mondial | +43,1 % | +4,9 % | +29,1 % | −13,6 % |
| Prudent | +28,3 % | +9,1 % | +17,1 % | −12,0 % |
| Opportuniste | +32,1 % | +7,3 % | +27,4 % | −13,7 % |
| Audacieux | +13,3 % (chute max −42 %) | +33,6 % | +48,1 % | **−46,4 %** |
| Kamikaze | +20,6 % (32 485 € de frais) | +106,5 % | +5,8 % | **−50,8 %** |

- Audacieux fait +13,3 % à l'entraînement contre +36,0 % au tour 10, sans changement de code : les archives
  BBC/CNBC de 2016-2019 ont continué d'arriver. Les résultats d'avant/après restent comparables à l'intérieur
  d'un même tour (même copie figée), pas d'un tour à l'autre.

Défauts relevés dans les simulations du tour 10 (validation 2020-2022) :
- **Audacieux** : −46 % en 2022 (indice −14 %). 100 % de ses ordres sont des changements de posture
  (≈ 100 ordres et 5 000 à 11 000 € de frais par an) : sa posture suit la note de climat du moment, qui bouge
  tous les jours (la « confirmation » actuelle ne dure qu'un passage de 15 minutes).
- **Kamikaze** : 90 % de ses ordres sont des rotations de cheval (692 en 3 ans, 49 000 € de frais pour
  100 000 € de départ) : il change dès qu'un classement d'un seul jour le lui dit.
- Prudent et Opportuniste : pas de défaut de comportement net (Opportuniste suit l'indice ; Prudent est moins
  exposé par construction).

## Tour 12 · essais prévus (notés AVANT de lancer)
| Robot | Correction (une seule) | Essai n° pour ce robot |
|---|---|---|
| Audacieux | n°32 : la posture suit la moyenne de la note de climat sur 5 jours (même idée que Prudent n°4, déjà gardée) | 1 / 3 |
| Kamikaze | n°33 : un cheval n'est lâché que si l'envie de le lâcher dure depuis la veille (stop-loss toujours immédiat) | 1 / 3 |

### Résultats du tour 12 (26/09, 2 h 16 de calcul, même copie figée des archives)
| Robot | Correction | Entraînement | 2020 | 2021 | 2022 | Décision |
|---|---|---|---|---|---|---|
| Audacieux | n°32 : climat moyen sur 5 jours | +13,3 % → +18,5 % | +33,6 % → +20,4 % | +48,1 % → +51,5 % | −46,4 % → −54,8 % | ❌ REJETÉE (pire en 2020 et 2022) |
| Kamikaze | n°33 : attendre le lendemain avant de lâcher un cheval | +20,6 % → +33,8 % | +106,5 % → +68,9 % | +5,8 % → +23,6 % | −50,8 % → −57,9 % | ❌ REJETÉE (pire en 2020 et 2022) |

- Les deux corrections réduisent bien l'agitation (moins d'ordres, moins de frais) et gagnent à l'entraînement :
  avec la méthode A (validation d'un bloc), elles auraient été jugées sur l'ensemble 2020-2022, qu'elles
  perdent aussi (≈ +6 % → −17 % pour Audacieux, +8 % → −12 % pour Kamikaze). Réagir plus lentement coûte
  cher dans les retournements brutaux (krach de mars 2020, baisse de 2022).

## Tour 13 · essais prévus (notés AVANT de lancer)
| Robot | Correction (une seule) | Essai n° pour ce robot |
|---|---|---|
| Audacieux | n°34 : « par mer agitée, on réduit la voilure » — chaque placement à levier est réduit quand sa volatilité (20 jours) dépasse sa volatilité habituelle (médiane de ce que le robot a déjà vu, jamais la suite) ; le reste au sans-risque | 2 / 3 |
| Kamikaze | n°35 : classer selon l'élan de fond (semaines, mois) au lieu du sprint de quelques jours, que les études trouvent surtout fait de bruit qui se retourne | 2 / 3 |

### Résultats du tour 13 (26/09 soir, 2 h 14)
| Robot | Correction | Entraînement | 2020 | 2021 | 2022 | Décision |
|---|---|---|---|---|---|---|
| Kamikaze | n°35 : élan de fond au lieu du sprint | +20,6 % → +6,4 % | +106,5 % → +93,9 % | +5,8 % → −7,5 % | −50,8 % → −58,8 % | ❌ REJETÉE (pire partout) |
| Audacieux | n°34 : réduire la voilure par mer agitée | — | — | — | — | ⚠️ NON JOUÉ : erreur de programmation de ma part (un nom oublié, le robot plantait à chaque passage et n'a passé aucun ordre). Corrigé, et contrôle automatique ajouté ; l'essai est rejoué tel quel au tour 13 bis (ce n'est pas un nouvel essai) |

### Tour 13 bis (27/09 nuit, 2 h 09) — essai n°34 rejoué après correction de mon erreur
| Robot | Correction | Entraînement | 2020 | 2021 | 2022 | Décision |
|---|---|---|---|---|---|---|
| Audacieux | n°34 : réduire la voilure par mer agitée | +13,3 % → +14,9 % | +33,6 % → +27,4 % | +48,1 % → +41,6 % | −46,4 % → −45,1 % | ❌ REJETÉE (pire en 2020 et 2021 ; à peine mieux en 2022) |

## Bilan provisoire de la méthode B (27/09, ~2h45)
- 4 essais joués (Audacieux 2/3, Kamikaze 2/3, Prudent 0/3, Opportuniste 0/3) : **aucun gardé**.
- Ce que ça apprend : Audacieux et Kamikaze perdent la moitié de leur argent en 2022 (−46 %, −51 %) quoi qu'on
  essaie ; leurs gains de 2020-2021 viennent du même levier qui les fait chuter en 2022. Ralentir leurs
  réactions (n°32, n°33) ou alléger le levier par gros temps (n°34) les fait rater les rebonds de 2020-2021
  sans vraiment les protéger en 2022.
- Prudent et Opportuniste : pas de défaut de comportement net ; pas d'essai « pour essayer » (on ne dépense
  pas un essai sans défaut à corriger).
- Suite prévue : quand les archives BBC/CNBC 2020-2022 seront téléchargées, révision des 9 corrections de la
  méthode A avec la règle B, puis le dernier essai d'Audacieux et de Kamikaze.

## Tour 14 · essai prévu (noté AVANT de lancer, 27/09/2026) — demandé par le propriétaire
| Robot | Correction (une seule) | Essai n° pour ce robot |
|---|---|---|
| Audacieux | n°36 : « pas de pari de crise par beau temps » — une alerte de crise ne déclenche le pari à la baisse ×2 que si la note de climat est **≤ 0** (seuil fixé avant de lancer). Défaut observé : dans la simulation mai 2025-mai 2026 (avec Éco), 19 paris de crise, dont plusieurs par climat « optimiste » (+41, +43), presque tous perdants, et 14 000 € de frais | 3 / 3 (dernier) |
Règle B : gardée seulement si mieux sur l'entraînement (2016-2019) ET sur 2020, 2021 et 2022 séparément.
Mêmes archives que les tours 11 à 13 bis (BBC, CNBC… pas encore téléchargées pour 2020-2022 : surtout Google Actualités).

## 28/09 — préparation de la fin de la méthode B
- **Révision automatique** (`python -m bourse.labo.revision --attendre`, lancée le 28/09 vers 8h15, en
  priorité basse) : elle attend que les archives 2020-2022 soient téléchargées (≥ 95 % des jours pour chaque
  source), puis retire une à une les 9 corrections de la méthode A et note ici si chacune tient avec la règle B.
- **Derniers essais d'Audacieux et de Kamikaze (3/3)** : pas lancés. Les trois idées de comportement essayées
  ont échoué pour la même raison (le levier qui les fait gagner en 2020-2021 les fait chuter en 2022) ; on ne
  dépense un essai qu'avec une idée nouvelle et solide, pas pour « tenter sa chance ».
- **Examen** : `python -m bourse.labo.examen` est prêt mais verrouillé tant que les archives 2023-2026 ne sont
  pas complètes ; il joue en une fois Présent, Méthode A et Méthode B, puis se bloque définitivement
  (fichier data/labo/EXAMEN_JOUE).
- Les simulations du labo tournent désormais toujours en priorité basse (la course du présent et Éco d'abord).
⚠️ 28/09 : l'essai n°36 a été interrompu (fermeture de la session) avant tout résultat ; il est rejoué tel quel (tour 14 bis, ce n'est pas un nouvel essai).

## Étude (30/09) : les paris à la baisse d'Audacieux gagnent-ils ? — entraînement 2016-2019 seulement
Données : simulation de référence du tour 11 (actuelle_entrainement.db), allers-retours sur le titre à la baisse ×2 (DBPK).
| Type | Nombre | Moyenne par pari | Paris gagnants |
|---|---|---|---|
| Pari de crise (alerte fraîche au vocabulaire de crise) | 13 | −0,8 % | 23 % |
| Posture « baisse » (climat mauvais + tendance cassée) | 12 | −1,5 % | 17 % |
Frais d'Audacieux sur la période : 19 903 €. Les alertes déclencheuses sont surtout géopolitiques (Iran/Israël/Syrie,
traité nucléaire russe, ingérence électorale) : graves, mais sans effet net sur la Bourse. Plus d'actualités
téléchargées = plus de ces alertes = plus de paris perdants : c'est la cause de la chute d'Audacieux entre le tour 10
(+36,0 %) et le tour 11 (+13,3 %) sans changement de code. Justifie l'essai n°36 (déjà inscrit, pas encore joué).

## Tour 15 · essais prévus (notés AVANT de lancer, 30/09/2026) — joués ensemble quand la mémoire le permettra
| Robot | Correction (une seule) | Essai n° pour ce robot |
|---|---|---|
| Audacieux | n°36 (inscrit au tour 14, jamais mené à terme : interrompu deux fois, fermeture de session puis manque de mémoire) — pari de crise seulement si note de climat ≤ 0 | 3 / 3 (dernier) |
| Kamikaze | n°37 : même règle — son pari de crise (tout sur la chute du Nasdaq ×3) seulement si note de climat ≤ 0. Justification : étude du 30/09 (2016-2019), 9 paris de crise, −0,6 % en moyenne, 44 % gagnants | 3 / 3 (dernier) |
Pas d'essai pour Prudent ni Opportuniste : aucun défaut net (Opportuniste gagne sur ses achats après alerte : 54 paris, +0,4 %, 63 % gagnants).
⚠️ Note d'honnêteté (30/09) : l'essai n°36 avait d'abord été motivé (27/09) par la simulation mai 2025 → sept. 2026 de l'onglet
Passé, qui tombe dans la période d'examen (2023-2026) — avant que la règle du professeur soit fixée. Sa justification
repose désormais uniquement sur l'étude du 30/09 (entraînement 2016-2019), qui montre le même défaut. Aucun résultat de
la simulation 2025-2026 ne sert à régler un robot.

### Résultats du tour 15 (30/09 → 01/10, terminé à 0 h 52)
| Robot | Correction | Entraînement | 2020 | 2021 | 2022 | Décision |
|---|---|---|---|---|---|---|
| Audacieux | n°36 : pari de crise seulement si note ≤ 0 | +3,8 % → −3,1 % | +85,0 % → +87,4 % | +48,1 % → +48,1 % | −46,4 % → −46,4 % | ❌ REJETÉE (pire à l'entraînement ; aucun effet en 2021-2022) |
| Kamikaze | n°37 : même règle | +11,9 % → −4,4 % | +78,4 % → +78,4 % | +5,8 % → +5,8 % | −50,8 % → −50,8 % | ❌ REJETÉE (pire à l'entraînement ; aucun effet en 2020-2022) |
- Les deux robots ont épuisé leurs 3 essais de la méthode B. Aucun effet en 2021-2022 : presque aucune alerte de crise
  ces années-là dans les archives disponibles (BBC/CNBC 2020-2022 pas encore téléchargées). Sans le pari de crise, ils
  restent au levier à la hausse pendant les vraies baisses de 2016-2019 : le pari perdait en moyenne, mais il amortissait
  parfois une chute. Leçon : un défaut mesuré (paris perdants) ne se corrige pas forcément en le supprimant.

## Révision des corrections de la méthode A avec la règle B (2026-10-09 21:42)
Chaque correction est retirée seule (les autres restent) : « avec » doit battre « sans » à l'entraînement ET en 2020, 2021 et 2022.

| Robot | Correction | Entraînement avec / sans | 2020 | 2021 | 2022 | Verdict |
|---|---|---|---|---|---|---|
| Prudent | n°4 climat lissé sur 5 jours | +26,2 % / +24,6 % | +6,8 % / +7,3 % | +13,5 % / +12,7 % | -15,4 % / -15,2 % | ❌ à retirer (méthode B) |
| Opportuniste | n°5 une seule mise en réserve | +32,5 % / +27,0 % | +5,9 % / -0,0 % | +26,1 % / +24,6 % | -15,0 % / -10,7 % | ❌ à retirer (méthode B) |
| Audacieux | n°2 garde son marché d'accompagnement (top 5) | +3,8 % / +2,6 % | +87,3 % / +84,7 % | +39,0 % / +33,5 % | -51,4 % / -53,5 % | ✅ confirmée |
| Kamikaze | n°1 garde un cheval tant qu'il est dans le top 5 | +11,9 % / -21,0 % | +78,4 % / +38,8 % | +2,9 % / +6,3 % | -55,5 % / -59,7 % | ❌ à retirer (méthode B) |
| Prudent | n°24 jusqu'à 85 % d'actions | +26,2 % / +23,6 % | +6,8 % / +7,3 % | +13,4 % / +11,8 % | -15,7 % / -15,1 % | ❌ à retirer (méthode B) |
| Opportuniste | n°13 pas de soldes en marché baissier | +32,5 % / +32,5 % | +5,9 % / +5,9 % | +26,1 % / +26,1 % | -14,8 % / -14,8 % | ❌ à retirer (méthode B) |
| Audacieux | n°6 marge anti-ping-pong de 10 points | +3,8 % / +4,3 % | +87,3 % / +81,4 % | +32,3 % / +30,4 % | -57,3 % / -58,4 % | ❌ à retirer (méthode B) |
| Kamikaze | n°22 paris à la baisse seulement par tempête | +11,9 % / -1,0 % | +78,4 % / +21,1 % | +2,9 % / -32,8 % | -55,5 % / -45,8 % | ❌ à retirer (méthode B) |
| Prudent | n°28 au moins 45 % d'actions | +26,2 % / +23,3 % | +6,8 % / +6,4 % | +13,4 % / +12,4 % | -15,7 % / -15,5 % | ❌ à retirer (méthode B) |
| Opportuniste | n°25 30 jours pour rebondir | +32,5 % / +30,4 % | +5,9 % / +5,9 % | +26,1 % / +25,3 % | -14,8 % / -13,5 % | ❌ à retirer (méthode B) |

## 🎓 EXAMEN FINAL lancé le 12/10/2026 à 8 h 12 (accord du propriétaire, une seule fois)
Période 2023-01-01 → 12/10/2026, versions « Présent », « Méthode A », « Méthode B », même copie figée des archives
(sources quotidiennes complètes à 100 % sur la période). Verrou data/labo/EXAMEN_JOUE posé : jamais rejoué.
Correction du garde-fou avant le lancement : archives_pretes() ne compte plus « fed » et « bce:ANNÉE » (notés une fois
par période/année, ils bloquaient l'examen à tort). Résultats : data/labo/examen.json.

## 🎓 Résultats de l'EXAMEN (2023-01-01 → 2026-10-12, joué une seule fois, fini le 12/10 à 20 h 06)
| Robot | Présent (= version finale de la méthode B) | Méthode A | Indice mondial |
|---|---|---|---|
| Prudent | +48,2 % (chute max −10,8 %) | **+55,9 %** (−13,3 %) | +91,4 % |
| Opportuniste | +56,8 % (−14,9 %) | **+67,9 %** (−18,7 %) | +91,4 % |
| Audacieux | +101,5 % (−35,5 %) | **+118,9 %** (−28,6 %) | +91,4 % |
| Kamikaze | −33,2 % (−61,3 %) | **+51,1 %** (−46,1 %) | +91,4 % |
⚠️ Écart de procédure : la ligne « methode_B » de examen.json a rejoué la version A (parametres.yaml du labo jamais mis à
jour après la révision du 09/10, qui retirait les 9 corrections de A). Comme la méthode B n'a gardé aucune correction, sa
version finale est celle du présent : son vrai résultat est la ligne « present ». L'examen n'a pas été rejoué.
Leçon : la méthode A (31 essais, 9 corrections) bat la méthode B (0 correction) sur les 4 robots à l'examen ; la règle B
(« mieux sur l'entraînement ET chaque année 2020, 2021, 2022 ») a rejeté des corrections qui tenaient hors échantillon.
Rappel methodes.md : choisir une version d'après cet examen, c'est déjà s'en servir ; le juge neuf reste la course du présent.

## 🏁 Décision du 23/10/2026 (le propriétaire : « fais ce qui te semble le mieux »)
- **Les robots d'origine restent dans la course, inchangés** (leur historique depuis le 24/09 est gardé).
- **Ajoutés à la course du présent, à côté d'eux (100 000 € fictifs chacun, départ le 23/10)** : Prudent, Opportuniste,
  Audacieux et Kamikaze « (méthode A) », réglages vérifiés identiques à ceux joués à l'examen, et « Audacieux (méthode B) »
  = original + n°2 (seule correction confirmée par la révision). Code figé : src/bourse/strategies/methode_a.py.
- Pourquoi ne pas remplacer : la méthode A a gagné l'examen, mais 9 de ses 10 corrections ne tiennent pas année par année
  (révision B), et l'examen 2023-2026 était une période de hausse, comme 2016-2022 : il ne peut pas trancher si A est
  meilleure ou seulement plus investie en actions par marché haussier. La course du présent départagera, sans que personne
  ait vu les réponses.
- Précision sur le tableau de l'examen : la version finale B de l'Audacieux n'était pas tout à fait le présent (n°2
  confirmée) ; elle n'a jamais été examinée, elle est jugée seulement au présent.
- Rien n'est corrigé d'après l'examen ; le labo ne rejoue pas l'examen.
- Robot Éco : option 1 (réglages par principe seulement, déjà fait le 05/10 pour la v2) ; pas de découpage de sa période
  2025-2026, dont j'ai déjà vu les résultats.
